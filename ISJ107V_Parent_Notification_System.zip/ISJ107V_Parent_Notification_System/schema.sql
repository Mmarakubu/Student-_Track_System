CREATE DATABASE IF NOT EXISTS school_attendance
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE school_attendance;

CREATE TABLE IF NOT EXISTS parents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(30),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','security','parent') NOT NULL,
  parent_id INT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_user_parent FOREIGN KEY (parent_id) REFERENCES parents(id)
);

CREATE TABLE IF NOT EXISTS learners (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  admission_number VARCHAR(50) NOT NULL UNIQUE,
  grade VARCHAR(30) NOT NULL,
  parent_id INT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_learner_parent FOREIGN KEY (parent_id) REFERENCES parents(id),
  INDEX idx_learner_parent (parent_id)
);

CREATE TABLE IF NOT EXISTS attendance_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  learner_id INT NOT NULL,
  event_type ENUM('ENTRY','EXIT') NOT NULL,
  event_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  gate_name VARCHAR(100) NOT NULL DEFAULT 'Main Gate',
  recognition_method ENUM('MANUAL_DEMO','SIMULATED_RECOGNITION') NOT NULL,
  captured_by INT NULL,
  CONSTRAINT fk_event_learner FOREIGN KEY (learner_id) REFERENCES learners(id),
  CONSTRAINT fk_event_user FOREIGN KEY (captured_by) REFERENCES users(id),
  INDEX idx_event_time (event_time),
  INDEX idx_event_learner_time (learner_id,event_time)
);

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  parent_id INT NOT NULL,
  learner_id INT NOT NULL,
  event_id BIGINT NULL,
  message VARCHAR(500) NOT NULL,
  channel ENUM('in_app','email') NOT NULL DEFAULT 'in_app',
  status ENUM('queued','sent','failed') NOT NULL DEFAULT 'queued',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notice_parent FOREIGN KEY (parent_id) REFERENCES parents(id),
  CONSTRAINT fk_notice_learner FOREIGN KEY (learner_id) REFERENCES learners(id),
  CONSTRAINT fk_notice_event FOREIGN KEY (event_id) REFERENCES attendance_events(id),
  INDEX idx_notice_parent (parent_id,created_at)
);

CREATE TABLE IF NOT EXISTS access_attempts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  reference_code VARCHAR(80),
  gate_name VARCHAR(100) NOT NULL DEFAULT 'Main Gate',
  outcome ENUM('UNRECOGNISED') NOT NULL,
  attempted_by INT NULL,
  attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_attempt_user FOREIGN KEY (attempted_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(100) NOT NULL,
  details VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_audit_created (created_at)
);
