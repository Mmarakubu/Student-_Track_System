"""Create the first administrator account. Run: python seed.py"""
import os
import mysql.connector
from werkzeug.security import generate_password_hash
from dotenv import load_dotenv

load_dotenv()
conn = mysql.connector.connect(
    host=os.getenv("DB_HOST", "localhost"),
    port=int(os.getenv("DB_PORT", "3306")),
    user=os.getenv("DB_USER", "root"),
    password=os.getenv("DB_PASSWORD", ""),
    database=os.getenv("DB_NAME", "school_attendance")
)
cur = conn.cursor()
name = input("Administrator full name: ").strip()
email = input("Administrator email: ").strip().lower()
password = input("Administrator password (minimum 10 characters): ")
if len(password) < 10:
    raise SystemExit("Use a password with at least 10 characters.")
cur.execute(
    "INSERT INTO users (full_name,email,password_hash,role) VALUES (%s,%s,%s,'admin')",
    (name, email, generate_password_hash(password))
)
conn.commit()
print("Administrator created. You can now log in.")
cur.close()
conn.close()
