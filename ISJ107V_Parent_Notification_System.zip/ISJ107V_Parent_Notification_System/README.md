# ISJ107V – Integrated Student Entry/Exit and Parent Notification System

A Flask + MySQL academic prototype based on the submitted ISJ107V project proposal.

## Included modules

- Role-based login: administrator, security staff and parent
- Learner registration and parent/guardian records
- Simulated facial-recognition workflow using a learner admission number
- Manual attendance capture as a fallback
- Entry/exit event history
- Parent in-app notifications
- Parent portal showing linked learners, notifications and event history
- Unrecognised-attempt alerts
- Date-filtered attendance reports and CSV export
- Audit log database table
- Configurable missing-attendance check (default example cutoff: 08:30)

## Important prototype limitation

The "facial recognition" page is a **simulation**. It matches a typed demo admission number to a learner record. It does not capture, analyse, generate, or store face images or biometric templates. Do not use this prototype to make real school access decisions. A production biometric solution requires a formal privacy impact assessment, appropriate consent/authority, secure biometric processing, accuracy/bias testing, human review, retention rules and legal review.

Notifications are stored in the parent's in-app portal. Email delivery is not configured in this starter project; connect an approved email provider before describing email/SMS as operational.

## 1. Requirements

- Python 3.10 or newer
- MySQL Server 8.0 or newer
- A terminal / command prompt
- A modern web browser

## 2. Create the database

1. Start MySQL Server.
2. Open MySQL Workbench or a MySQL terminal.
3. Run the complete contents of `schema.sql`.

This creates the `school_attendance` database and all tables.

## 3. Install the Python dependencies

Open a terminal in this project folder.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Windows

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 4. Configure the database connection

Copy `.env.example` to a new file named `.env`.

Update the values to match your MySQL installation:

```env
SECRET_KEY=put-a-long-random-value-here
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=school_attendance
FLASK_DEBUG=false
```

Never upload `.env` or share real passwords.

## 5. Create the first administrator

With the virtual environment active, run:

```bash
python seed.py
```

Enter an administrator name, email and password when prompted. The password is stored as a one-way hash.

## 6. Start the application

```bash
python app.py
```

Open:

`http://127.0.0.1:5000`

Log in with the administrator email and password created in Step 5.

## 7. Suggested demonstration sequence

1. Log in as administrator.
2. Open **Parents** and create a parent account. Use a demonstration email and temporary password.
3. Open **Learners** and register a learner linked to that parent.
4. Open **Recognition Demo**. Enter the learner's admission number and choose ENTRY.
5. Open **Attendance** and confirm that the entry event was saved.
6. Log out and log in using the parent's email and temporary password.
7. Open the Parent Portal and show the notification and event history.
8. Log back in as administrator/security and demonstrate EXIT.
9. Enter a made-up admission number on Recognition Demo to show an unrecognised attempt in Alerts.
10. Open Reports, choose a date range and export the CSV report.

## 8. Roles and permissions

| Function | Admin | Security | Parent |
|---|---:|---:|---:|
| View school dashboard | Yes | Yes | Redirected to portal |
| Register parent accounts | Yes | No | No |
| Register/deactivate learners | Yes | View | No |
| Capture entry/exit | Yes | Yes | No |
| View unrecognised attempts | Yes | Yes | No |
| View/export attendance reports | Yes | Yes | No |
| View linked child events/notices | No | No | Own linked children only |
| Create staff accounts | Yes | No | No |

## 9. Database overview

- `users`: login accounts and roles
- `parents`: parent/guardian contact records
- `learners`: learner details and parent relationship
- `attendance_events`: entry/exit records
- `notifications`: parent in-app notifications
- `access_attempts`: unrecognised demo attempts
- `audit_logs`: important user actions

## 10. Troubleshooting

**MySQL connection error**
- Confirm MySQL Server is running.
- Check `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` and `DB_NAME` in `.env`.
- Confirm that `schema.sql` ran successfully.

**ModuleNotFoundError**
- Activate `.venv`.
- Run `pip install -r requirements.txt`.

**Access denied / login fails**
- Run `python seed.py` to create the first administrator.
- Confirm you are using the exact email and password entered during setup.

**CSRF token missing**
- Refresh the page and submit the form again. Keep cookies enabled.

## 11. Before real-world deployment

This is an educational prototype, not a production school security platform. Before deployment:
- use HTTPS and secure hosting;
- set a strong secret key and database-specific least-privilege account;
- add password reset, account lockout and stronger session controls;
- implement parent identity/relationship verification and documented consent;
- complete POPIA and child-data privacy reviews with the school;
- add secure notification provider integration and delivery/retry monitoring;
- add backups, retention/deletion workflows and security testing;
- use human verification and a safe manual fallback for every uncertain identification;
- do not use a face match alone to deny a learner entry or exit.

## Project structure

```text
ISJ107V_Parent_Notification_System/
├── app.py
├── schema.sql
├── seed.py
├── requirements.txt
├── .env.example
├── README.md
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── learners.html
│   ├── parents.html
│   ├── attendance.html
│   ├── recognition.html
│   ├── alerts.html
│   ├── parent_portal.html
│   ├── reports.html
│   └── error.html
└── static/
    └── style.css
```
