import os
import csv
import io
from datetime import datetime, date, time
from functools import wraps

import mysql.connector
from mysql.connector import Error
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, abort
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from flask_wtf.csrf import CSRFProtect

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-development-secret")
csrf = CSRFProtect(app)

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "school_attendance"),
    "autocommit": False,
}

def db():
    return mysql.connector.connect(**DB_CONFIG)

def query(sql, params=(), one=False, commit=False):
    conn = db()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute(sql, params)
        result = cur.fetchone() if one else cur.fetchall()
        if commit:
            conn.commit()
        return result
    finally:
        cur.close()
        conn.close()

def execute(sql, params=()):
    conn = db()
    cur = conn.cursor()
    try:
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        cur.close()
        conn.close()

def current_user():
    if "user_id" not in session:
        return None
    return query(
        "SELECT id, full_name, email, role, parent_id FROM users WHERE id=%s AND is_active=1",
        (session["user_id"],), one=True
    )

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            user = current_user()
            if not user or user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator

def audit(user_id, action, details=""):
    execute(
        "INSERT INTO audit_logs (user_id, action, details) VALUES (%s,%s,%s)",
        (user_id, action, details[:500])
    )

def create_notification(learner_id, event_id, message):
    learner = query(
        """SELECT p.id AS parent_id, p.email, p.phone, p.full_name
           FROM learners l JOIN parents p ON p.id=l.parent_id WHERE l.id=%s""",
        (learner_id,), one=True
    )
    if not learner:
        return
    execute(
        """INSERT INTO notifications
           (parent_id, learner_id, event_id, message, channel, status)
           VALUES (%s,%s,%s,%s,'in_app','sent')""",
        (learner["parent_id"], learner_id, event_id, message)
    )
    # Optional email delivery can be added using an approved SMTP provider.
    # The in-app notification is always recorded for the prototype.

def record_event(learner_id, event_type, gate, method, captured_by=None):
    learner = query("SELECT id, full_name FROM learners WHERE id=%s AND is_active=1",
                    (learner_id,), one=True)
    if not learner:
        raise ValueError("Learner was not found or is inactive.")

    event_id = execute(
        """INSERT INTO attendance_events
           (learner_id, event_type, gate_name, recognition_method, captured_by)
           VALUES (%s,%s,%s,%s,%s)""",
        (learner_id, event_type, gate, method, captured_by)
    )
    label = "entered" if event_type == "ENTRY" else "exited"
    message = f"{learner['full_name']} has {label} the school campus at {datetime.now():%H:%M}."
    create_notification(learner_id, event_id, message)
    return event_id

@app.context_processor
def inject_globals():
    return {"logged_in_user": current_user(), "now": datetime.now()}

@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = query("SELECT * FROM users WHERE email=%s AND is_active=1", (email,), one=True)
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            audit(user["id"], "LOGIN", "Successful login")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    user = current_user()
    if user:
        audit(user["id"], "LOGOUT", "User logged out")
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    if user["role"] == "parent":
        return redirect(url_for("parent_portal"))

    stats = {
        "learners": query("SELECT COUNT(*) AS n FROM learners WHERE is_active=1", one=True)["n"],
        "entries_today": query("""SELECT COUNT(*) AS n FROM attendance_events
                                  WHERE event_type='ENTRY' AND DATE(event_time)=CURDATE()""", one=True)["n"],
        "exits_today": query("""SELECT COUNT(*) AS n FROM attendance_events
                                WHERE event_type='EXIT' AND DATE(event_time)=CURDATE()""", one=True)["n"],
        "notifications": query("""SELECT COUNT(*) AS n FROM notifications
                                  WHERE DATE(created_at)=CURDATE()""", one=True)["n"],
    }
    recent = query("""SELECT ae.*, l.full_name, l.admission_number
                      FROM attendance_events ae JOIN learners l ON l.id=ae.learner_id
                      ORDER BY ae.event_time DESC LIMIT 10""")
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/learners")
@roles_required("admin", "security")
def learners():
    rows = query("""SELECT l.*, p.full_name AS parent_name, p.phone AS parent_phone
                    FROM learners l JOIN parents p ON p.id=l.parent_id
                    ORDER BY l.full_name""")
    parents = query("SELECT id, full_name, email FROM parents ORDER BY full_name")
    return render_template("learners.html", learners=rows, parents=parents)

@app.route("/learners/add", methods=["POST"])
@roles_required("admin")
def add_learner():
    name = request.form.get("full_name", "").strip()
    admission = request.form.get("admission_number", "").strip()
    grade = request.form.get("grade", "").strip()
    parent_id = request.form.get("parent_id", "").strip()
    if not all([name, admission, grade, parent_id]):
        flash("Please complete all learner fields.", "warning")
        return redirect(url_for("learners"))
    try:
        execute("""INSERT INTO learners
                   (full_name, admission_number, grade, parent_id)
                   VALUES (%s,%s,%s,%s)""", (name, admission, grade, int(parent_id)))
        audit(current_user()["id"], "LEARNER_CREATED", f"Created learner {admission}")
        flash("Learner registered successfully.", "success")
    except Error as exc:
        flash(f"Could not register learner. Check that the admission number is unique. ({exc})", "danger")
    return redirect(url_for("learners"))

@app.route("/learners/<int:learner_id>/deactivate", methods=["POST"])
@roles_required("admin")
def deactivate_learner(learner_id):
    execute("UPDATE learners SET is_active=0 WHERE id=%s", (learner_id,))
    audit(current_user()["id"], "LEARNER_DEACTIVATED", f"Learner ID {learner_id}")
    flash("Learner deactivated.", "success")
    return redirect(url_for("learners"))

@app.route("/parents", methods=["GET", "POST"])
@roles_required("admin")
def parents():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        if not all([name, email, password]):
            flash("Name, email and temporary password are required.", "warning")
        else:
            try:
                parent_id = execute(
                    "INSERT INTO parents (full_name,email,phone) VALUES (%s,%s,%s)",
                    (name, email, phone)
                )
                execute(
                    """INSERT INTO users (full_name,email,password_hash,role,parent_id)
                       VALUES (%s,%s,%s,'parent',%s)""",
                    (name, email, generate_password_hash(password), parent_id)
                )
                audit(current_user()["id"], "PARENT_CREATED", email)
                flash("Parent and portal account created.", "success")
            except Error:
                flash("Could not create parent. The email may already be registered.", "danger")
        return redirect(url_for("parents"))
    rows = query("SELECT * FROM parents ORDER BY full_name")
    return render_template("parents.html", parents=rows)

@app.route("/attendance")
@roles_required("admin", "security")
def attendance():
    rows = query("""SELECT ae.*, l.full_name, l.admission_number, l.grade
                    FROM attendance_events ae JOIN learners l ON l.id=ae.learner_id
                    ORDER BY ae.event_time DESC LIMIT 100""")
    learners_list = query("SELECT id, full_name, admission_number FROM learners WHERE is_active=1 ORDER BY full_name")
    return render_template("attendance.html", events=rows, learners=learners_list)

@app.route("/attendance/capture", methods=["POST"])
@roles_required("admin", "security")
def capture_attendance():
    learner_id = request.form.get("learner_id", "")
    event_type = request.form.get("event_type", "")
    gate = request.form.get("gate_name", "Main Gate").strip() or "Main Gate"
    if event_type not in ("ENTRY", "EXIT"):
        flash("Select a valid event type.", "warning")
        return redirect(url_for("attendance"))
    try:
        record_event(int(learner_id), event_type, gate, "MANUAL_DEMO", current_user()["id"])
        audit(current_user()["id"], "ATTENDANCE_CAPTURED", f"{event_type}, learner ID {learner_id}")
        flash("Attendance event captured and parent in-app notification created.", "success")
    except (ValueError, Error):
        flash("Could not capture attendance. Please check the learner selection.", "danger")
    return redirect(url_for("attendance"))

@app.route("/recognition", methods=["GET", "POST"])
@roles_required("admin", "security")
def recognition():
    result = None
    if request.method == "POST":
        demo_code = request.form.get("demo_code", "").strip()
        event_type = request.form.get("event_type", "ENTRY")
        gate = request.form.get("gate_name", "Main Gate").strip() or "Main Gate"
        learner = query(
            "SELECT * FROM learners WHERE admission_number=%s AND is_active=1",
            (demo_code,), one=True
        )
        if learner and event_type in ("ENTRY", "EXIT"):
            record_event(learner["id"], event_type, gate, "SIMULATED_RECOGNITION", current_user()["id"])
            audit(current_user()["id"], "SIMULATED_RECOGNITION", f"{event_type}, learner {demo_code}")
            result = {"ok": True, "message": f"Demo identification successful: {learner['full_name']}."}
        else:
            execute("""INSERT INTO access_attempts (reference_code, gate_name, outcome, attempted_by)
                       VALUES (%s,%s,'UNRECOGNISED',%s)""",
                    (demo_code[:80], gate, current_user()["id"]))
            audit(current_user()["id"], "UNRECOGNISED_ATTEMPT", f"Demo code {demo_code}")
            result = {"ok": False, "message": "No active learner matched that demo admission number. An alert was logged."}
    return render_template("recognition.html", result=result)

@app.route("/alerts")
@roles_required("admin", "security")
def alerts():
    rows = query("""SELECT aa.*, u.full_name AS staff_name FROM access_attempts aa
                    LEFT JOIN users u ON u.id=aa.attempted_by ORDER BY aa.attempted_at DESC LIMIT 100""")
    return render_template("alerts.html", alerts=rows)

@app.route("/parent")
@roles_required("parent")
def parent_portal():
    user = current_user()
    children = query("SELECT * FROM learners WHERE parent_id=%s AND is_active=1 ORDER BY full_name",
                     (user["parent_id"],))
    notices = query("""SELECT n.*, l.full_name FROM notifications n
                       JOIN learners l ON l.id=n.learner_id
                       WHERE n.parent_id=%s ORDER BY n.created_at DESC LIMIT 50""",
                    (user["parent_id"],))
    events = query("""SELECT ae.*, l.full_name FROM attendance_events ae
                      JOIN learners l ON l.id=ae.learner_id
                      WHERE l.parent_id=%s ORDER BY ae.event_time DESC LIMIT 50""",
                   (user["parent_id"],))
    return render_template("parent_portal.html", children=children, notices=notices, events=events)

@app.route("/reports")
@roles_required("admin", "security")
def reports():
    start = request.args.get("start", date.today().isoformat())
    end = request.args.get("end", date.today().isoformat())
    rows = query("""SELECT ae.event_time, l.admission_number, l.full_name, l.grade,
                           ae.event_type, ae.gate_name, ae.recognition_method
                    FROM attendance_events ae JOIN learners l ON l.id=ae.learner_id
                    WHERE DATE(ae.event_time) BETWEEN %s AND %s
                    ORDER BY ae.event_time DESC""", (start, end))
    return render_template("reports.html", rows=rows, start=start, end=end)

@app.route("/reports/export")
@roles_required("admin", "security")
def export_report():
    start = request.args.get("start", date.today().isoformat())
    end = request.args.get("end", date.today().isoformat())
    rows = query("""SELECT ae.event_time, l.admission_number, l.full_name, l.grade,
                           ae.event_type, ae.gate_name, ae.recognition_method
                    FROM attendance_events ae JOIN learners l ON l.id=ae.learner_id
                    WHERE DATE(ae.event_time) BETWEEN %s AND %s
                    ORDER BY ae.event_time DESC""", (start, end))
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date/time", "Admission number", "Learner", "Grade", "Event", "Gate", "Capture method"])
    for row in rows:
        writer.writerow([row["event_time"], row["admission_number"], row["full_name"],
                         row["grade"], row["event_type"], row["gate_name"], row["recognition_method"]])
    return Response(output.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=attendance_report.csv"})

@app.route("/admin/check-missing", methods=["POST"])
@roles_required("admin")
def check_missing():
    # Default school start time is configurable through the form.
    cutoff = request.form.get("cutoff", "08:30")
    try:
        cutoff_time = datetime.strptime(cutoff, "%H:%M").time()
    except ValueError:
        flash("Invalid time. Use HH:MM.", "warning")
        return redirect(url_for("dashboard"))
    if datetime.now().time() < cutoff_time:
        flash(f"It is before the configured attendance cutoff ({cutoff}). No check was run.", "info")
        return redirect(url_for("dashboard"))
    missing = query("""SELECT l.id, l.full_name, p.id AS parent_id
                       FROM learners l JOIN parents p ON p.id=l.parent_id
                       WHERE l.is_active=1 AND NOT EXISTS (
                         SELECT 1 FROM attendance_events ae
                         WHERE ae.learner_id=l.id AND ae.event_type='ENTRY'
                         AND DATE(ae.event_time)=CURDATE())""")
    for learner in missing:
        msg = f"Attendance reminder: {learner['full_name']} has no recorded school entry today."
        execute("""INSERT INTO notifications
                   (parent_id, learner_id, message, channel, status)
                   VALUES (%s,%s,%s,'in_app','sent')""",
                (learner["parent_id"], learner["id"], msg))
    audit(current_user()["id"], "MISSING_ATTENDANCE_CHECK", f"{len(missing)} parent alerts")
    flash(f"Attendance check completed. {len(missing)} parent notification(s) created.", "success")
    return redirect(url_for("dashboard"))

@app.route("/admin/create-user", methods=["POST"])
@roles_required("admin")
def create_staff_user():
    name = request.form.get("full_name", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    role = request.form.get("role", "")
    if role not in ("admin", "security") or not all([name, email, password]):
        flash("Provide valid staff details and role.", "warning")
    else:
        try:
            execute("""INSERT INTO users (full_name,email,password_hash,role)
                       VALUES (%s,%s,%s,%s)""",
                    (name, email, generate_password_hash(password), role))
            audit(current_user()["id"], "STAFF_USER_CREATED", email)
            flash("Staff account created.", "success")
        except Error:
            flash("Could not create account. Email may already exist.", "danger")
    return redirect(url_for("dashboard"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="You do not have permission to access this page."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="The page you requested was not found."), 404

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
